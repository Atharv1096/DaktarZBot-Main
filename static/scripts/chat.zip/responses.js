function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }
    let questioninput=input

    // Simple responses
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else {
        return "Try asking something else!";
    }
}

function UserAction(input) {

var json = JSON.stringify({
    "name": "Responsecode",
    "description": "",
    "questioninput":String(input),
    "renders": [
        "application/json",
        "text/html"
    ],
    "parses": [
        "application/json",
        "application/x-www-form-urlencoded",
        "multipart/form-data"
    ]
})

/*var output;
var r = $.post('http://127.0.0.1:8000/response/', json, function(response){
  output = response;
  //output = String(output);
  return output;
}, 'json').responseText;

return r;*/

var output;
$.ajax({
                url: 'http://127.0.0.1:8000/response/',
                method: 'post',
                dataType: 'json',
                data: json,
                contentType: 'application/json',
                success: function (data) {
                    output = data.d.responseText;
                },
                error: function (ex) {
                    alert(ex.responseText);
                }
            });
return output;
//console.log(function(response));
//return String(r.json());
}
